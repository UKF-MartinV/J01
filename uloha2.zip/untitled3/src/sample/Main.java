package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application {
    int poc_sam  = 0;
    int poc_spol = 0;
    int dlz = 0;
    Label label1 = new Label();
    Label label2 = new Label();
    @Override
    public void start(Stage primaryStage) throws Exception{
        Group root = new Group();

        TextField textField = new TextField("Hello");
        root.getChildren().add(textField);


        label1.setLayoutX(50);
        label1.setLayoutY(50);


        label2.setLayoutX(200);
        label2.setLayoutY(200);


        Button Button1 = new Button("Napíš");
        Button1.setLayoutX(100);
        Button1.setLayoutY(100);



        Button1.setOnAction(event ->{
            String vst = textField.getText();
            poc_spol = 0;
            poc_sam = 0;
            dlz = vst.length();
            label2.setText(" ");

            label1.setText(textField.getText());

        for (int i=0; i<dlz; i++)
        {
            char znak = vst.charAt(i);
            String final_znak = znak + "";
            char znak2 =' ';
            String final_znak2 = " ";
            if (i>1)
            {
                znak2 = vst.charAt(i-1);
                final_znak2 = znak + "";
            }
            if ((final_znak.equals("a"))||(final_znak.equals("e"))||(final_znak.equals("i"))||(final_znak.equals("o"))||(final_znak.equals("u"))||(final_znak.equals("y")))
            {poc_sam++;}
            else if ((final_znak.equals("A"))||(final_znak.equals("E"))||(final_znak.equals("I"))||(final_znak.equals("O"))||(final_znak.equals("U"))||(final_znak.equals("Y")))
            {poc_sam++;}
            else if ((final_znak.equals("h"))||(final_znak.equals("k"))||(final_znak.equals("g"))||(final_znak.equals("d"))||(final_znak.equals("t"))||(final_znak.equals("n"))||(final_znak.equals("l")))
            {poc_spol++;}
            else if ((final_znak.equals("H"))||(final_znak.equals("K"))||(final_znak.equals("G"))||(final_znak.equals("D"))||(final_znak.equals("T"))||(final_znak.equals("N"))||(final_znak.equals("L")))
            {poc_spol++;}
            else if ((final_znak.equals("b"))||(final_znak.equals("m"))||(final_znak.equals("p"))||(final_znak.equals("r"))||(final_znak.equals("s"))||(final_znak.equals("v"))||(final_znak.equals("z"))||(final_znak.equals("f")))
            {poc_spol++;}
            else if ((final_znak.equals("B"))||(final_znak.equals("M"))||(final_znak.equals("P"))||(final_znak.equals("R"))||(final_znak.equals("S"))||(final_znak.equals("V"))||(final_znak.equals("Z"))||(final_znak.equals("F")))
            {poc_spol++;}
            else if ((final_znak.equals("ď"))||(final_znak.equals("ť"))||(final_znak.equals("ň"))||(final_znak.equals("ľ"))||(final_znak.equals("č"))||(final_znak.equals("ž"))||(final_znak.equals("š"))||(final_znak.equals("c"))||(final_znak.equals("j")))
            {poc_spol++;}
            else if ((final_znak.equals("Ď"))||(final_znak.equals("Ť"))||(final_znak.equals("Ň"))||(final_znak.equals("Ľ"))||(final_znak.equals("Č"))||(final_znak.equals("Ž"))||(final_znak.equals("Š"))||(final_znak.equals("C"))||(final_znak.equals("J")))
            {poc_spol++;}

            if ((final_znak.equals("h"))&&(final_znak2.equals("c")))
            {poc_spol--;}
            else if ((final_znak.equals("H"))&&(final_znak2.equals("C")))
            {poc_spol--;}
            else if ((final_znak.equals("h"))&&(final_znak2.equals("C")))
            {poc_spol--;}
            else if ((final_znak.equals("H"))&&(final_znak2.equals("c")))
            {poc_spol--;}

            if ((final_znak.equals("z"))&&(final_znak2.equals("d")))
            {poc_spol--;}
            else if ((final_znak.equals("Z"))&&(final_znak2.equals("D")))
            {poc_spol--;}
            else if ((final_znak.equals("Z"))&&(final_znak2.equals("d")))
            {poc_spol--;}
            else if ((final_znak.equals("z"))&&(final_znak2.equals("D")))
            {poc_spol--;}

            if ((final_znak.equals("ž"))&&(final_znak2.equals("d")))
            {poc_spol--;}
            else if ((final_znak.equals("Ž"))&&(final_znak2.equals("D")))
            {poc_spol--;}
            else if ((final_znak.equals("Ž"))&&(final_znak2.equals("d")))
            {poc_spol--;}
            else if ((final_znak.equals("ž"))&&(final_znak2.equals("D")))
            {poc_spol--;}
        }
        if (((poc_sam*16) < 256)&&((poc_spol*24) < 256)&&(((dlz % 25)*10) < 256))
        {
            label1.setTextFill(Color.rgb(poc_sam*16,poc_spol*24, (dlz % 25)*10));
        }




        label2.setText("Sam:" + poc_sam + ", Sp: " + poc_spol + ", Spolu:" + dlz);

                }
        );
        root.getChildren().add(label2);
        root.getChildren().add(label1);
        root.getChildren().add(Button1);
        primaryStage.setTitle("Text");
        primaryStage.setScene(new Scene(root, 400, 500));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
