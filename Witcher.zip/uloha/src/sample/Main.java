package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.scene.paint.Color;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Group root = new Group();
        vykresli(50,50,root);
        primaryStage.setScene(new Scene(root, 800, 600));
        primaryStage.show();
    }
    public void znak1(int x1, int y1, Group root)
    {
        Line znak_A1 =new Line();
        znak_A1.setStroke(Color.PURPLE);
        znak_A1.setStartX(x1+40);
        znak_A1.setStartY(y1+80);
        znak_A1.setEndX(x1+70);
        znak_A1.setEndY(y1+80);
        root.getChildren().add(znak_A1);

        Line znak_A3 =new Line();
        znak_A3.setStroke(Color.PURPLE);
        znak_A3.setStartX(x1+70);
        znak_A3.setStartY(y1+110);
        znak_A3.setEndX(x1+40);
        znak_A3.setEndY(y1+80);
        root.getChildren().add(znak_A3);

        Line znak_A2 =new Line();
        znak_A2.setStroke(Color.PURPLE);
        znak_A2.setStartX(x1+40);
        znak_A2.setStartY(y1+110);
        znak_A2.setEndX(x1+70);
        znak_A2.setEndY(y1+110);
        root.getChildren().add(znak_A2);

        Line znak_A4 =new Line();
        znak_A4.setStroke(Color.PURPLE);
        znak_A4.setStartX(x1+70);//
        znak_A4.setStartY(y1+80);//
        znak_A4.setEndX(x1+60);
        znak_A4.setEndY(y1+90);
        root.getChildren().add(znak_A4);

        Line znak_A5 =new Line();
        znak_A5.setStroke(Color.PURPLE);
        znak_A5.setStartX(x1+50);
        znak_A5.setStartY(y1+100);
        znak_A5.setEndX(x1+40);//
        znak_A5.setEndY(y1+110);//
        root.getChildren().add(znak_A5);
    }
    public void znak2(int x1, int y1, Group root)
    {
        Line znak_A1 =new Line();
        znak_A1.setStroke(Color.YELLOW);
        znak_A1.setStartX(x1+40);
        znak_A1.setStartY(y1+80);
        znak_A1.setEndX(x1+70);
        znak_A1.setEndY(y1+80);
        root.getChildren().add(znak_A1);

        Line znak_A2 =new Line();
        znak_A2.setStroke(Color.YELLOW);
        znak_A2.setStartX(x1+40);
        znak_A2.setStartY(y1+80);
        znak_A2.setEndX(x1+55);
        znak_A2.setEndY(y1+110);
        root.getChildren().add(znak_A2);

        Line znak_A3 =new Line();

        znak_A3.setStroke(Color.YELLOW);
        znak_A3.setStartX(x1+62);
        znak_A3.setStartY(y1+95);
        znak_A3.setEndX(x1+55);
        znak_A3.setEndY(y1+110);
        root.getChildren().add(znak_A3);

        Line znak_A4 =new Line();

        znak_A4.setStroke(Color.YELLOW);
        znak_A4.setStartX(x1+70);
        znak_A4.setStartY(y1+80);
        znak_A4.setEndX(x1+67);
        znak_A4.setEndY(y1+87);
        root.getChildren().add(znak_A4);

        Line znak_A5 =new Line();

        znak_A5.setStroke(Color.YELLOW);
        znak_A5.setStartX(x1+55);
        znak_A5.setStartY(y1+87);
        znak_A5.setEndX(x1+67);
        znak_A5.setEndY(y1+87);
        root.getChildren().add(znak_A5);
    }
    public void znak3(int x1, int y1, Group root)
    {
        Line znak_A1 =new Line();
        znak_A1.setStroke(Color.RED);
        znak_A1.setStartX(x1+40);
        znak_A1.setStartY(y1+110);
        znak_A1.setEndX(x1+70);
        znak_A1.setEndY(y1+110);
        root.getChildren().add(znak_A1);

        Line znak_A2 =new Line();
        znak_A2.setStroke(Color.RED);
        znak_A2.setStartX(x1+40);
        znak_A2.setStartY(y1+110);
        znak_A2.setEndX(x1+55);
        znak_A2.setEndY(y1+80);
        root.getChildren().add(znak_A2);

        Line znak_A3 =new Line();
        znak_A3.setStroke(Color.RED);
        znak_A3.setStartX(x1+60);
        znak_A3.setStartY(y1+87);
        znak_A3.setEndX(x1+70);
        znak_A3.setEndY(y1+110);
        root.getChildren().add(znak_A3);

    }
    public void znak4(int x1, int y1, Group root)
    {
        Line znak_A1 =new Line();
        znak_A1.setStroke(Color.GREEN);
        znak_A1.setStartX(x1+40);
        znak_A1.setStartY(y1+80);
        znak_A1.setEndX(x1+70);
        znak_A1.setEndY(y1+80);
        root.getChildren().add(znak_A1);

        Line znak_A2 =new Line();
        znak_A2.setStroke(Color.GREEN);
        znak_A2.setStartX(x1+40);
        znak_A2.setStartY(y1+80);
        znak_A2.setEndX(x1+55);
        znak_A2.setEndY(y1+110);
        root.getChildren().add(znak_A2);

        Line znak_A3 =new Line();
        znak_A3.setStroke(Color.GREEN);
        znak_A3.setStartX(x1+67);
        znak_A3.setStartY(y1+87);
        znak_A3.setEndX(x1+55);
        znak_A3.setEndY(y1+110);
        root.getChildren().add(znak_A3);

    }
    public void znak5(int x1, int y1, Group root)
    {
        Line znak_A1 =new Line();

        znak_A1.setStroke(Color.LIGHTBLUE);
        znak_A1.setStartX(x1+40);
        znak_A1.setStartY(y1+110);
        znak_A1.setEndX(x1+70);
        znak_A1.setEndY(y1+110);
        root.getChildren().add(znak_A1);

        Line znak_A2 =new Line();
        znak_A2.setStroke(Color.LIGHTBLUE);
        znak_A2.setStartX(x1+70);
        znak_A2.setStartY(y1+110);
        znak_A2.setEndX(x1+55);
        znak_A2.setEndY(y1+80);
        root.getChildren().add(znak_A2);

        Line znak_A3 =new Line();
        znak_A3.setStroke(Color.LIGHTBLUE);
        znak_A3.setStartX(x1+47);
        znak_A3.setStartY(y1+95);
        znak_A3.setEndX(x1+40);
        znak_A3.setEndY(y1+110);
        root.getChildren().add(znak_A3);

        Line znak_A4 =new Line();
        znak_A4.setStroke(Color.LIGHTBLUE);
        znak_A4.setStartX(x1+51);
        znak_A4.setStartY(y1+88);
        znak_A4.setEndX(x1+55);
        znak_A4.setEndY(y1+80);
        root.getChildren().add(znak_A4);

        Line znak_A5 =new Line();
        znak_A5.setStroke(Color.LIGHTBLUE);
        znak_A5.setStartX(x1+47);
        znak_A5.setStartY(y1+95);
        znak_A5.setEndX(x1+55);
        znak_A5.setEndY(y1+95);
        root.getChildren().add(znak_A5);
    }
    public void vykresli(int x1, int y1, Group root){
    znak1(x1,y1,root); //50,50
    znak2(x1+40,y1,root); //x+40
    znak3(x1+80,y1,root); //x+40*2
    znak4(x1+120,y1,root); //x+40*3
    znak5(x1+160,y1,root); //x+40*4
    }

    public static void main(String[] args) {
        launch(args);
    }
}
